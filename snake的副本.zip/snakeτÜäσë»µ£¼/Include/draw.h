#ifndef DRAW_H
#define DRAW_H

void DrawApple(double x, double y); 

void DrawButton(double dx, double dy, const string str);

void EraseButton(double dx, double dy, const string str);

void DrawWall(double x, double y);

void DrawArea();

void DrawBody(double x, double y);

void DrawBox(double x, double y);

void fillRectangle(double x, double y, double w, double h);

void fillR(double x, double y, double w, double h,string color);

void DrawSnake();

void DrawHead();

void SnakeHead(double x, double y); 


void LevelTravel(int level);



#endif
