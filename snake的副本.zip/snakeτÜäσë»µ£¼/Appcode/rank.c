
#include "graphics.h"
#include "extgraph.h"
#include "strlib.h"
#include "conio.h"
#include <stdio.h>
#include <windows.h>

#include "menu.h"
#include "hardware.h"
#include "basicgame.h"
#include "rank.h"
#include "draw.h"

extern double winwidth, winheight;
extern int score;                  
extern char nameID[20];

void InputInfo()
{
	const char *fpName = "record.txt";
 	FILE *fp;
 	struct Save s1;  	
 	s1.score = score;
 	strcpy(s1.Name,nameID);
	fp = fopen(fpName, "ab"); 
	if(NULL == fp)
 	{
  		MessageBox(NULL,"THE FILE CANNOT OPEN!","ERROR",MB_ICONHAND);
  		exit(0);
 	}
 	fwrite(&s1,sizeof(struct Save),1,fp); 
 	fclose(fp);
 	return;
}

void OutputInfo()   
{
	const char *fpName = "record.txt";
 	FILE *fp;
 	struct Save *head, *tail, *p;
	char RankOutput[5],ScoreOutput[10]; //����������������ַ��� 
	int i, j, len, number;
	struct Save s2[10], temp; 
	head = tail = NULL;
	
	fp = fopen(fpName, "rb"); 
	if(NULL == fp)
	{
		return; 
	}
	fseek(fp,0,SEEK_END);
	len = ftell(fp);
	number = len/sizeof(struct Save);
	fseek(fp, 0, SEEK_SET);
	for(i=0;i<number;i++)
		fread(&s2[i],sizeof(struct Save),1,fp);
		
	for(i=0;i<number-1;i++)//ѡ������ 
	{
		for(j=i;j<number;j++)
		{
			if(s2[i].score<s2[j].score)
			{
				temp = s2[i];
				s2[i] = s2[j];
				s2[j] = temp;
			}
		}
	}
	
	for(i=0;i<number;i++)
	{
		p = (struct Save*) malloc (sizeof(struct Save));
		p->score = s2[i].score;
		strcpy(p->Name, s2[i].Name);
		p->next = NULL;
		if(head == NULL)
			head = p;
		else
			tail->next = p;
		tail = p;
	}
	SetPointSize(23);
	SetPenColor("brown");
	MovePen(winwidth*0.32,winheight*0.7+0.8);  
	DrawTextString("Rank");
	MovePen(winwidth*0.44,winheight*0.7+0.8); 
	DrawTextString("Name");
	MovePen(winwidth*0.56,winheight*0.7+0.8); 
	DrawTextString("Score"); 
	SetPointSize(22);
	SetPenColor("brown");
	for(i = 0,p = head;p != NULL&& i < 10; p = p->next,i++)//��� 
	{ 
		itoa(i+1, RankOutput, 10);
		itoa(p->score, ScoreOutput, 10);
		MovePen(winwidth*0.32,winheight*0.7-i*0.3); 
		DrawTextString(RankOutput);
		MovePen(winwidth*0.44,winheight*0.7-i*0.3); 
		DrawTextString(p->Name);
		MovePen(winwidth*0.56,winheight*0.7-i*0.3); 
		DrawTextString(ScoreOutput);
	}
	fclose(fp);
	SetPointSize(10); 
	return;
}

