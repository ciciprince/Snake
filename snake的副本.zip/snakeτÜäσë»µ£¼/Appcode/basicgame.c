
#include "graphics.h"
#include "extgraph.h"
#include "conio.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include <olectl.h>


#include "basicgame.h"
#include "menu.h"
#include "hardware.h"
#include "rank.h"
#include "draw.h"


#define  INIT_X                0      
#define  INIT_Y                0      
#define  GAME_WIDTH            7      
#define  GAME_HEIGHT           7      
#define  BUTTON_WIDTH          2    
#define  BUTTON_HEIGHT         0.5    
#define  BOX_WIDTH             0.292  

#define CURSOR "_"             
#define CURSOR_BLINK  1        
#define TEXTLEN  100

extern TextT curText;          
extern int timerseconds;       
extern bool isCursorBlink;     
extern TextT tptr;             
extern bool inText;            
extern char textbuf[TEXTLEN+1];
extern char* PenColor[6];       
extern char* Speed[4];         
extern int show_more_buttons;
extern int _color;              
extern double winwidth, winheight;
extern int isAccelerate;       
extern int CurrentDirection; 
extern int LastDirection;
extern int TempDirection;   
extern int d;                   
extern int speed;               
extern bool isStart;            
extern int domain[24][24];        
extern isLogin;                
extern Start;             
extern int isRank;
extern int high, low;
extern int score, add;
extern char nameID[20];
extern bool isEnd;
extern int GameLevel;

//��ʾ��ǰ������ɫ 
void ShowCurrentColor(void){
	SetPenColor(PenColor[_color]);
	MovePen(7.2, 5.2);
	DrawTextString("The color of the snake :");
	MovePen(9.2, 5.2);
	DrawTextString(PenColor[_color]);
} 

//��ʾ��ǰ�ٶȱ��� 
void ShowCurrentSpeed(void){
	SetPenColor("blue");
	MovePen(7.8, 5.6);
	DrawTextString("Speed | F1 : "); 
	MovePen(8.7,5.6);
	SetEraseMode(TRUE);
	DrawTextString(Speed[(isAccelerate + 3) % 4]);
	SetEraseMode(FALSE);
	MovePen(8.7,5.6);
	DrawTextString(Speed[isAccelerate]);
}

//��ʾ���ʵʱ���� 
void ShowCurrentScore(void){
	SetPenColor("blue");
	MovePen(7.8, 6.0);
	DrawTextString("Your Scores ��");
	
}

bool inBox(double x0, double y0, double x1, double x2, double y1, double y2)
{
	return (x0 >= x1 && x0 <= x2 && y0 >= y1 && y0 <= y2);
}

void ChangeColor(){
	SetEraseMode(TRUE); 
    MovePen(9.2,5.2);  
    DrawTextString(PenColor[_color]);//���֮ǰ������ 
    DrawButton(7.5,2.4,"ReStart |F3");
	DrawButton(7.5,1.7,"Color |F2"); 
	DrawButton(7.5,0.3,"Exit |ESC"); 
    SetEraseMode(FALSE);
 	_color = rand() % 6;
 	ShowCurrentColor();
 	DrawButton(7.5,2.4,"ReStart |F3");
	DrawButton(7.5,1.7,"Color |F2"); 
	DrawButton(7.5,0.3,"Exit |ESC");   
	if (isStart) {
		SetPenColor(PenColor[_color]);
		SetEraseMode(TRUE);
		DrawButton(7.5,1.0,"Pause |SPACE"); 
		SetEraseMode(FALSE);
		DrawButton(7.5,1.0,"Pause |SPACE");
    } 
	else {
		SetPenColor(PenColor[_color]);
		SetEraseMode(TRUE);
		DrawButton(7.5,1.0,"Play |SPACE"); 
		SetEraseMode(FALSE);
		DrawButton(7.5,1.0,"Play |SPACE");
    }
}

void scoretip(void)
{	
    char s[100];
	SetPenSize(1);
	SetPenColor("blue");
	MovePen(7.8,6.0);
	sprintf(s,"Your Scores ��%d", score);
    DrawTextString(s);
}
void CreateNewGame(){
	isStart = 0;
    CurrentDirection = 1;
    LastDirection = 1;
    TempDirection = 1;
	SetPenColor("white");
	fillRectangle(0, 0, GAME_WIDTH, GAME_HEIGHT);
	InitSnake();
	DrawSnake();
	CreatFood();
	DrawArea();
}

void StartGame(){
	isStart = !isStart;
		if (isStart) {
			startTimer(1, speed);
            fillR(7.45,0.9,2.2,0.65,"white");
			SetPenColor(PenColor[_color]);
			DrawButton(7.5,1.0,"Pause |SPACE");
		} 
		else {
			cancelTimer(1);
            fillR(7.45,0.9,2.2,0.65,"white");
			SetPenColor(PenColor[_color]);
			DrawButton(7.5,1.0,"Play |SPACE");
		}
}

void CreatFood()	
{
	int x, y;
	srand((unsigned)time(NULL));
	while (1)
	{ 
	    if(isStart){
			
			fillR(apple.fx*BOX_WIDTH,apple.fy*BOX_WIDTH,BOX_WIDTH,BOX_WIDTH,"white");
			DrawSnake();
		} 	
		x = rand() % 23;  //ѡ��һ��������� 
		y = rand() % 23;
        switch(GameLevel){
        	case 0:
        		if(x == 0 || y == 0){  //��ֹ�����ڿ��� 
        	        continue;
			    }
			    break;
            case 1:
            	if(x == 0 || y == 0 || (x >= 9 && x < 15 && y >= 9 && y < 15)){  //��ֹ�����ڿ��� ����ǽ���� 
        	        continue;
			    }
			    break;
			case 2:
				if(x == 0 || y == 0){  //��ֹ�����ڿ��� 
        	        continue;
			    }
				else if(x >= 6 && x < 10 && y >= 6 && y < 10){
					continue;
				}
				else if(x >= 14 && x < 18 && y >= 6 && y < 10){
					continue;
				}
				else if(x >= 6 && x < 10 && y >= 14 && y < 18){
					continue;
				}
				else if(x >= 14 && x < 18 && y >= 14 && y < 18){
					continue;
				}
		} 
		if (domain[x][y] != 1&domain[x][y] != 2&&domain[x][y] != 3&&&domain[x][y] != 4 )  //�����ǰ���겻������ 
		{
			domain[x][y] = 5;                                                   //���õ�ǰ������5����ʾʳ�� 
			SetPenColor("green"); 
			DrawApple(x*BOX_WIDTH,y*BOX_WIDTH);                    //��ʳ��
			apple.fx = x;
			apple.fy = y;
			break;
		}

	}

}

void InitSnake(){     //������ʼ����ͷ��㣨3,10����β��㣨1,10�����ܹ�ռ�������飬�������� 
	int i, j;
	head.x = 3;
	head.y = 10;
	tail.x = 1;
	tail.y = 10;
	for(i = 0; i < 24; i++){
		for(j = 0; j < 24;j++){
			domain[i][j] = 0;
		}
	}
	domain[1][10] = 1;
	domain[2][10] = 1;
	domain[3][10] = 1;
}


bool DeathJudge(double x,double y){       //�ж��Ƿ�����
	switch(GameLevel){
		case 0:
			if(x == 0 ||x == 23||((x < 3||x >= 8)&&y == 0)||((x < 3||x >= 8)&&y == 23)){
				return 1;
			}
			else
			    return 0;
			break;
		case 1:
			if(x == 0 || y == 0 || x == 23 || y == 23){
				return 1;
			}
			else if(x >= 9 && x < 15 && y >= 9 && y < 15){
				return 1;
			}
			else 
			    return 0;
			break;	
		case 2:
			//����Χǽ���ж� 
		    if((x == 0 || x == 23) && ((y >= 0 && y < 9) || y >= 15)){
		    	return 1;
		    }	
		    else if((y == 0 || y == 23) && ((x >= 0 && x < 9) || x >= 15)){
		    	return 1;
		    }
		    //�ĸ����ε��ж� 
			else if(x >= 6 && x < 10 && y >= 6 && y < 10){
				return 1;
			}
			else if(x >= 14 && x < 18 && y >= 6 && y < 10){
				return 1;
			}
			else if(x >= 6 && x < 10 && y >= 14 && y < 18){
				return 1;
			}
			else if(x >= 14 && x < 18 && y >= 14 && y < 18){
				return 1;
			}
			else{
			    return 0;
			}		
	}
}

void DeathTip(void){
	fillR(0,2,7,3,"yellow");
	SetPenColor("gray");
	SetPointSize(1);
    DrawLine(0, 3);
    DrawLine(7, 0);
    DrawLine(0, -3);
    DrawLine(-7, 0);
	SetPointSize(60);
	MovePen(1.5,3.5); 
	DrawTextString(" YOU LOSE ! ");
	SetPointSize(5);
	MovePen(2.4,2.9);
	DrawTextString(" Press ESC to exit. ");
}


