#include <graphics.h>
#include "extgraph.h"
#include "strlib.h"
#include "conio.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>

#include "basicgame.h"
#include "hardware.h"
#include "menu.h"
#include "rank.h"
#include "draw.h"

#define  INIT_X                0      
#define  INIT_Y                0      
#define  GAME_WIDTH            7      
#define  GAME_HEIGHT           7      
#define  BUTTON_WIDTH          2    
#define  BUTTON_HEIGHT         0.5    
#define  BOX_WIDTH             0.292  

#define CURSOR "_"             
#define CURSOR_BLINK  1        
#define TEXTLEN  100

extern TextT curText;          
extern int timerseconds;       
extern bool isCursorBlink;     
extern TextT tptr;             
extern bool inText;            
extern char textbuf[TEXTLEN+1];
extern char* PenColor[6];       
extern char* Speed[4];         
extern int show_more_buttons;
extern int _color;              
extern double winwidth, winheight;
extern int isAccelerate;       
extern int CurrentDirection;    
extern int d;                   
extern int speed;               
extern bool isStart;            
extern int domain[24][24];        
extern isLogin;                
extern Start;             
extern int isRank;
extern int high, low;
extern int score, add;
extern char nameID[20];
extern bool isEnd;
extern int GameLevel;


//������Ϣ�ص�����  
void KeyboardEventProcess(int key,int event)
{	 
    switch (event) {
	    case KEY_DOWN:
            switch (key) {
			    case VK_SPACE://��ͣ�������� 
                    if(!Start){
                        break;
                    }
                    if(isEnd){
                    	break;
                    }
                    SetPenColor("gray");
					fillRectangle(7.5,1.0,2,0.5);
					SetPenColor(PenColor[_color]);
					StartGame();
                    break;
                case VK_UP:
                	if(isEnd){
                    	break;
                    }
                    d=2;
                    if((d+CurrentDirection)%2!=0)
                        CurrentDirection=2;
                    break;
			    case VK_DOWN:
			    	if(isEnd){
                    	break;
                    }
			     	d=4;
			     	if((d+CurrentDirection)%2!=0)
                        CurrentDirection=4;
                    break;
			    case VK_LEFT:
			        if(isLogin){
			     	    if (!inText) 
						 break;
	                    SetEraseMode(TRUE);
		 	   			MovePen(tptr->x, tptr->y);
		 	   			DrawTextString(textbuf);
						DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y); 
	                    if (tptr->curPos>0) tptr->curPos--;
	                    SetEraseMode(FALSE);
		 	   			MovePen(tptr->x, tptr->y);
		 	   			DrawTextString(textbuf);
						DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);
						break;                     
			     	} 
			        else{
			        	if(isEnd){
                    	    break;
                        }
			     	    d=3;
			     	    if((d+CurrentDirection)%2!=0)
                            CurrentDirection=3;
                        break;
			     	    }
			    case VK_RIGHT:
                    if(isLogin){
                    	if (!inText) break;
	                    SetEraseMode(TRUE);
		 	   			MovePen(tptr->x, tptr->y);
		 	   			DrawTextString(textbuf);
						DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);
	                    if (tptr->curPos<strlen(textbuf)) tptr->curPos++;
	                    SetEraseMode(FALSE);
		 	   			MovePen(tptr->x, tptr->y);
		 	   			DrawTextString(textbuf);
						DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);
					    break;                     
                    }
					else{
						if(isEnd){
                    		break;
                    	}
                    	d=1;
			     	    if((d+CurrentDirection)%2!=0)
                        CurrentDirection=1;
                        break;
                    }
				case VK_ESCAPE://�˳����� 
				    if(Start||isEnd){
				    	ExitGraphics();
				    }
                case VK_F1:  //�ı��ߵ��ٶ� 
                 	if(!Start){
                        break;
                    }
                    if(isEnd){
                    	break;
                    }
					if(isAccelerate == 0){ //1.5���� 
						
					    speed = 133;
                 		isAccelerate = 1;
                 		add = 15;
                 		startTimer(1, speed);
                 		ShowCurrentSpeed();
                 	} 
                 	else if(isAccelerate == 1){ //2���� 
                 		speed = 100;
                 		isAccelerate = 2;
                 	    startTimer(1, speed);
                 	    add = 20;
                 	    ShowCurrentSpeed();
                 	} 
                 	else if(isAccelerate == 2){  //4���� 
                 		speed = 50;
                 		isAccelerate = 3;
                 		startTimer(1, speed);
                 		add = 50;
                 		ShowCurrentSpeed();
                 	} 
                 	else if(isAccelerate == 3){ //�ص�ԭ�ٶ� 
                 		speed = 200;
                 		isAccelerate = 0;
                 		startTimer(1, speed);
                 		add = 10;
                 		ShowCurrentSpeed();
                 	} 
                 	break; 
                case VK_F2:     //�ı��ߵ���ɫ 
                    if(!Start){
                        break;
                    }	
					ChangeColor();
					break;
				case VK_F3:    //���¿�ʼ
					if(isLogin){
					  	break;
					  }
					if(!Start){
                     	break;
                    }
                    
				    isEnd = 0;
				    GameLevel = 0;
				    score = 0;
				    fillR(7.8,6.0,1.4,0.15,"white");
				    SetPenColor("blue");
				    MovePen(7.8,6.0);
			        DrawTextString("Your Scores ��0");
				    CreateNewGame();   
			    case VK_DELETE:
				    if (inText) { 
						SetEraseMode(TRUE);
						MovePen(tptr->x, tptr->y);
						DrawTextString(textbuf);
						DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);
						DeleteCharFromString(textbuf, tptr->curPos);
				 	   	SetEraseMode(FALSE);
				 	   	MovePen(tptr->x, tptr->y);
				 	   	DrawTextString(textbuf);
				 	   	DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);
				    	break;	
				    }
			}
			break;
	    case KEY_UP:
			break;
	}	 
}
//��ʱ���ص����� 
void TimerEventProcess(int timerID)
{
    switch (timerID) {
	    case 1: 
	        if (score >= 100 && GameLevel == 0){
				LevelTravel(1);
				GameLevel++;
				isStart = 0;
	        	CreateNewGame();
	        }
	        else if(score >= 300 && GameLevel == 1){
				LevelTravel(2);
	        	GameLevel++;
	        	isStart = 0;
				CreateNewGame();
	        }
		    if (!isStart) return;
	        SetEraseMode(TRUE);
		    DrawSnake();	  
	        domain[head.x][head.y] = CurrentDirection;
	        int tailD= domain[tail.x][tail.y];            
		    tmp = tail;                                
	        domain[tail.x][tail.y]=0;                      
            switch(GameLevel){ 
	        	case 0:
	        	case 1:
	        		if(tailD==1){                               
		          	    tail.x+=1;
		          	    
		            }
		            else if(tailD==2){
		          	    tail.y+=1;
		         	    if(tail.x >= 3 && tail.x <8){
		         	    	tail.y%=24;
		          	    }
		            }
		            else if(tailD==3){
		          	    tail.x-=1;
		          	    
		            }
		            else if(tailD==4){
		          	    tail.y-=1;
		          	    if(tail.x >= 3 && tail.x <8){
		          	    	if(tail.y<0){
		          	    		tail.y+=24;
		          	    	}
		                }
		            }
		          
		            if(CurrentDirection==1){  
		          	    head.x+=1;
							
		            }
		            else if(CurrentDirection==2){
		          	    head.y+=1;
		          	    if(head.x >= 3 && head.x <8){
		          	    	head.y%=24;
		          	    }
		          	    
		            }
		            else if(CurrentDirection==3){
		          	    head.x-=1;
		          	    
		            }
		            else if(CurrentDirection==4){
		          	    head.y -= 1;
		          	    if(head.x >= 3 && head.x <8){
		          	    	if(head.y<0){
		          	    		head.y += 24;
		          	    	}
		          	    }
		            }
		            break;
		        case 2:
		        	if(tailD==1){ 
		        	    tail.x+=1;
					    if(tail.y >= 9 && tail.y <15){
							tail.x %= 24;
		          	    }                        
		            }
		            else if(tailD==2){
		          	    tail.y += 1;
		         	    if(tail.x >= 9 && tail.x <15){
		         	        tail.y %= 24;
		          	    }
		            }
		            else if(tailD==3){
		          	    tail.x -= 1;
		          	    if(tail.y >= 9 && tail.y <15){
		          	    	if(tail.x<0){
		          	    		tail.x+=24;
		          	    	}
		                }
		            }
		            else if(tailD==4){
		          	    tail.y -= 1;
		          	    if(tail.x >= 9 && tail.x <15){
		          	    	if(tail.y<0){
		          	    		tail.y+=24;
		          	    	}
		                }
		            }
		          
		            if(CurrentDirection==1){                  
		          	    head.x += 1;
						if(head.y >= 9 && head.y <15){
		          	    	head.x %= 24;
		          	    }	
		            }
		            else if(CurrentDirection==2){
		          	    head.y += 1;
		          	    if(head.x >= 9 && head.x < 15){
		          	    	head.y%=24;
		          	    }
		            }
		            else if(CurrentDirection==3){
		          	    head.x-=1;
		          	    if(head.y >= 9 && head.y <15){
		          	    	if(head.x<0){
		          	    		head.x+=24;
		          	    	}
		          	    }
		            }
		            else if(CurrentDirection==4){
		          	    head.y-=1;
		          	    if(head.x >= 9 && head.x <15){
		          	    	if(head.y<0){
		          	    		head.y+=24;
		          	    	}
		          	    }
		            }
		            break;
	        }
            if(domain[head.x][head.y]==5) {  //�Ե�ʳ���жϣ�ʵʱ������ʾ  
		        char s[100];
				tail = tmp;                                 
		      	domain[tail.x][tail.y] = tailD;
		      	SetEraseMode(FALSE);
		      	SetPenColor("white");
		      	MovePen(7.8,6.0);
				sprintf(s,"Your Scores ��%d", score);
		        DrawTextString(s);
		        MovePen(7.8,6.0);
		      	score += add;
				SetPenColor("blue");
		    	sprintf(s,"Your Scores ��%d", score);
		        DrawTextString(s);
            }
            if(domain[head.x][head.y]!=0&&domain[head.x][head.y]!=5){  //��ײ���������� 
	            cancelTimer(1);
	          	DeathTip();
	          	newplayer.score = score;
	          	isEnd = 1;
	         	InputInfo();
	          	break;
            }
            if(DeathJudge(head.x,head.y)){                       //��ײ��ǽ������ 
	          	cancelTimer(1);
	          	DeathTip();
	          	newplayer.score = score;
	          	isEnd = 1;
	          	InputInfo();
	          	break;
            }
            domain[head.x][head.y]=CurrentDirection;
            SetEraseMode(FALSE);
			if(domain[tail.x-1][tail.y]!=5 && (tail.x!=0 && tail.x!=23)){
				fillR(BOX_WIDTH*(tail.x-1),BOX_WIDTH*tail.y,BOX_WIDTH,BOX_WIDTH,"white");
			}
            if(domain[tail.x+1][tail.y]!=5 && (tail.x!=0 && tail.x!=23)){
				fillR(BOX_WIDTH*(tail.x+1),BOX_WIDTH*tail.y,BOX_WIDTH,BOX_WIDTH,"white");
			}
			if(domain[tail.x][tail.y-1]!=5 && (tail.x!=0 && tail.x!=23)){
				fillR(BOX_WIDTH*tail.x,BOX_WIDTH*(tail.y-1),BOX_WIDTH,BOX_WIDTH,"white");
			}
			if(domain[tail.x][tail.y+1]!=5 && (tail.x!=0 && tail.x!=23)){
				fillR(BOX_WIDTH*tail.x,BOX_WIDTH*(tail.y+1),BOX_WIDTH,BOX_WIDTH,"white");
			}
			if((tail.y==0 || tail.y==23)&&domain[tail.x][23-tail.y]	!= 5){
				fillR(BOX_WIDTH*tail.x,BOX_WIDTH*(23-tail.y),BOX_WIDTH,BOX_WIDTH,"white");
			}
			if((tail.x==0 || tail.x==23)&&domain[23-tail.x][tail.y]	!= 5){
				fillR(BOX_WIDTH*(23-tail.x),BOX_WIDTH*tail.y,BOX_WIDTH,BOX_WIDTH,"white");
			}
			DrawArea();		
			ShowCurrentSpeed();  
	        ShowCurrentColor(); 
	        scoretip(); 
	        char nametip[100];
		    MovePen(7.6,6.5);
		    SetPenColor("blue"); 
			sprintf(nametip," Welcome !!  Dr. %s", textbuf);
			DrawTextString(nametip);
		    DrawSnake();
            int i,j;
            int Exist = 0;            //�����жϵ�ͼ���Ƿ����ʳ�� 
            for(i=0; i<24; i++)
		  	    for(j=0; j<24; j++){
				    if(domain[i][j] == 5){
				        Exist = 1;
				    }
			    }    
		    if(Exist == 0){           //�����ھʹ���ʳ�� 
		  	    CreatFood(); 
		    }
		  
		    break;
		case 2:      //ע��IDʱ 
			SetEraseMode(!tptr->isDisplayed);
			DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);
			SetEraseMode(FALSE);
			MovePen(tptr->x, tptr->y);
			DrawTextString(textbuf);
			tptr->isDisplayed=!tptr->isDisplayed;
			break;  
	    default:
		    break;
	}
} 

//�����Ϣ�ص����� ��Ϊʵ�ְ�ť���µĽ���Ч����button up�� button down �ֲ� 
void MouseEventProcess(int x, int y, int button, int event)
{
     double mx, my;
 	 mx = ScaleXInches(x);
 	 my = ScaleYInches(y); 
    switch (event) {
        case BUTTON_DOWN:
            if (button == LEFT_BUTTON) {
				  if (inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,1.0,1.0 + BUTTON_HEIGHT)){  //��ʼ��ͣ��ť 
				      if(isLogin){
					  	  break;
					  }
					  if(!Start){
                     	  break;
                      }
                      if(isRank){
                      	  break;
                      } 
                      if(isEnd){
                    	  break;
                      }
					  fillR(7.45,0.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      if(!isStart){
				      	  DrawButton(7.6,0.95,"Play |SPACE");
				      }
				      else{	  
						  DrawButton(7.6,0.95,"Pause |SPACE");
				      }
				  }
				  else if (inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,0.3,0.3 + BUTTON_HEIGHT)){  //�˳���ť 
				      if(!Start){
                     	break;
                      }
					  if(isLogin){
					  	break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(7.45,0.2,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(7.6,0.25,"Exit | ESC");
				  }
				  else if (inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,1.7,1.7 + BUTTON_HEIGHT)){   //�ı���ɫ��ť 
				  	  if(isLogin){
					  	break;
					  }
					  if(!Start){
                     	break;
                      }
                      if(isRank){
                      	  break;
                      } 
                      if(isEnd){
                    	  break;
                      }
                      fillR(7.45,1.6,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(7.6,1.65,"Color |F2");
				  }
				  else if(inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,2.4,2.4 + BUTTON_HEIGHT)){   //���水ť 
				  	  if(isLogin){
					  	  break;
					  }
					  if(!Start){
                     	  break;
                      }
                      if(isRank){
                      	  break;
                      } 
				    fillR(7.45,2.3,2.2,0.65,"white");
					SetPenColor(PenColor[_color]);
				    DrawButton(7.6,2.35,"ReStart |F3");   
				  }
				  else if(inBox(mx,my,1.5,1.5 + BUTTON_WIDTH,3,3 + BUTTON_HEIGHT)){   //ע����Ϣ��ť 
					  if(Start){
                     	  break;
                      }
                      if(isRank){
                      	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
                      fillR(1.45,2.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(1.6,2.95,"Register");
				  }
				  else if (inBox(mx,my,3.5,3.5 + BUTTON_WIDTH,2.5,2.5 + BUTTON_HEIGHT) && isLogin == 1){  //ȷ����ť 
				  	  if(Start){
                     	  break;
                      }
                      if(isRank){
                      	  break;
                      } 
                      fillR(3.45,2.4,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(3.6,2.45,"Ready");
				  }
				  else if(inBox(mx,my,5.5,5.5 + BUTTON_WIDTH,3,3 + BUTTON_HEIGHT)){   //��ʼ��Ϸ��ť 
				      if(isLogin){
					      break;
				      }
				      if(isRank){
                      	  break;
                      }
					  if(Start){
                     	  break;
                      } 
				      fillR(5.45,2.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(5.6,2.95,"Start");
				  }
				  else if(inBox(mx,my,1.5,1.5 + BUTTON_WIDTH,2,2 + BUTTON_HEIGHT)){   //about��ť 
				  	  if(Start){
                     	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(1.45,1.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(1.6,1.95,"About");
				  }
				  else if(inBox(mx,my,5.5,5.5 + BUTTON_WIDTH,2,2 + BUTTON_HEIGHT)){   //help��ť 
				  	  if(Start){
                     	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(5.45,1.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(5.6,1.95,"Help");
				  }
				  else if(inBox(mx, my,3.5,3.5 + BUTTON_WIDTH,1,1 + BUTTON_HEIGHT)){ //rank��ť 
				      if(Start){
                     	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(3.45,0.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(3.6,0.95,"Rank");
				  }
				  else if(inBox(mx,my,5,5 + BUTTON_WIDTH,0.8,0.8 + BUTTON_HEIGHT)){     //return��ť 
				  	  if(Start){
                     	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(!isRank){
                      	  break;
                      } 
					  fillR(4.95,0.7,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(5.1,0.75,"Return");
				  }  	 
				  else break;
		    }
			else if (button == RIGHT_BUTTON)   break;
        case BUTTON_DOUBLECLICK:
			break;
        case BUTTON_UP:
  		 	if (button == LEFT_BUTTON) {
  		 		if (inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,1.0,1.0 + BUTTON_HEIGHT)){         //pause��ť 
					  if(isLogin){
					  	  break;
					  }
					  if(!Start){
                     	  break;
                      }
                      if(isRank){
                      	  break;
                      } 
                      if(isEnd){
                    	  break;
                      }
					  StartGame();
				}
				else if (inBox(mx, my, 7.6,7.6 + BUTTON_WIDTH,0.25,0.25 + BUTTON_HEIGHT)){  //�˳���ť 
				      if(!Start){
                     	break;
                      }
					  if(isLogin){
					  	break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(7.45,0.2,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(7.5,0.3,"Exit |ESC");
					  ExitGraphics();
				  }
				else if (inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,1.7,1.7 + BUTTON_HEIGHT)){   //��ɫ��ť 
				  	  if(!Start){
                     	break;
                      }
					  if(isLogin){
					  	break;
					  }
					  if(isRank){
                      	  break;
                      } 
                      if(isEnd){
                    	  break;
                      }
					  fillR(7.45,1.6,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(7.5,1.7,"Color |F2");
					  ChangeColor();
				  }
				else if(inBox(mx, my, 7.5,7.5 + BUTTON_WIDTH,2.4,2.4 + BUTTON_HEIGHT)){     //���水ť 
					if(!Start){
                     	break;
                    }
					if(isLogin){
					  	break;
					}
					if(isRank){
                      	break;
                    } 
					fillR(7.45,2.3,2.2,0.65,"white");
					SetPenColor(PenColor[_color]);
				    DrawButton(7.5,2.4,"ReStart |F3"); 
				    isEnd = 0;
				    GameLevel = 0;
				    score = 0;
				    fillR(7.8,5.9,1.4,0.3,"white");
				    SetPenColor("blue");
				    MovePen(7.8,6.0);
			        DrawTextString("Your Scores ��0 ");
				    CreateNewGame();  
				  } 
				else if(inBox(mx,my,1.5,1.5 + BUTTON_WIDTH,3,3 + BUTTON_HEIGHT)){            //ע����Ϣ��ť 
                      if(Start){
                     	break;
                      }
					  if(isLogin){
					  	break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(1.45,2.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(1.5,3,"Register");
					  Register();
					  isLogin = 1;
					  inText = TRUE;                /*�����µ��ı�������״̬*/
					  tptr = GetBlock(sizeof(*tptr));
					  tptr->x = 4.5;
				      tptr->y = 3.5;
					  MovePen(tptr->x, tptr->y);    /*�ı���ʾ��ʼλ��*/
					  DrawTextString(CURSOR);       /*��ʾ���*/
				      textbuf[0] = '\0';            /*�γ��ַ���*/
				      tptr->PointSize = GetPointSize();
				      tptr->color = GetPenColor();
				      tptr->isSelected = FALSE;
				      tptr->curPos = 0;             /*���õ�ǰ���λ��*/
				      tptr->isDisplayed = TRUE;     /*���ù����˸��־*/ 
				      startTimer(2, 500);           /*�����˸��ʱ������*/
				      isCursorBlink = TRUE;         /*���ù����˸��־*/
				  }
				else if (inBox(mx,my,3.5,3.5 + BUTTON_WIDTH,2.5,2.5 + BUTTON_HEIGHT) && isLogin == 1){  //ȷ����ť 
				  	  if(Start){
                     	  break;
                      }
					  if(!isLogin){
					  	  break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  Start = 1; 
					  isLogin = 0;
					  isRank = 0;
					  inText = FALSE;
					  GameLevel = 0;
					  fillR(3.45,2.4,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(3.5,2.5,"Ready");
				  	  isCursorBlink = FALSE;
				  	  cancelTimer(2);
					  SetPenColor("white");
				  	  fillRectangle(0, 0, winwidth, winheight);
					  strcpy(newplayer.name , textbuf);
					  strcpy(nameID, newplayer.name);
					  SetPenColor("white");
				  	  fillRectangle(0, 0, winwidth, winheight); 
					  DrawPicture("background2.bmp");
					  SetPenColor("white");
	                  fillRectangle(0, 0, GAME_WIDTH, GAME_HEIGHT);
	                  DrawArea();
	                  InitSnake();
	                  CreatFood();
	                  DrawSnake();
	                  ShowCurrentSpeed();  
	                  ShowCurrentColor(); 
	                  scoretip(); 
	                  DrawButton(7.5,2.4,"ReStart |F3");
	                  DrawButton(7.5,1.7,"Color |F2");
	                  DrawButton(7.5,1.0,"Play |SPACE"); 
	                  DrawButton(7.5,0.3,"Exit |ESC"); 
	                  char nametip[100];
		      	      MovePen(7.6,6.5);
		      	      SetPenColor("blue"); 
				      sprintf(nametip," Welcome !!  Dr. %s", textbuf);
				  	  DrawTextString(nametip);
				  }
				else if(inBox(mx,my,5.5,5.5 + BUTTON_WIDTH,3,3 + BUTTON_HEIGHT)){    //��ʼ��Ϸ��ť 
				      if(Start){
                     	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  Start = 1;
					  isLogin = 0;
					  isRank = 0; 
					  inText = FALSE;
					  GameLevel = 0;
					  fillR(5.45,2.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(5.5,3,"Start");
					  strcpy(newplayer.name , textbuf);
					  SetPenColor("white");
				  	  fillRectangle(0, 0, winwidth, winheight);
					  DefineColor("pink",0.996,0.75,0.793);  //����ۺ�ɫ
					  DrawPicture("background2.bmp");
					  SetPenColor("white");
	                  fillRectangle(0, 0, GAME_WIDTH, GAME_HEIGHT);
					  DrawArea();
	                  InitSnake();
	                  CreatFood();
	                  DrawSnake();
	                  ShowCurrentSpeed();  //��ʾ��ǰ�ߵ��ٶ� 
	                  ShowCurrentColor();  //��ʾ��ǰ�ߵ���ɫ 
	                  scoretip(); 
	                  DrawButton(7.5,2.4,"ReStart |F3");
	                  DrawButton(7.5,1.7,"Color |F2");
	                  DrawButton(7.5,1.0,"Play |SPACE"); 
	                  DrawButton(7.5,0.3,"Exit |ESC");
				  }
				else if(inBox(mx,my,1.5,1.5 + BUTTON_WIDTH,2,2 + BUTTON_HEIGHT)){   //about��ť 
				  	  if(Start){
                     	break;
                      }
					  if(isLogin){
					  	break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(1.45,1.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(1.5,2,"About");
					  About();
			    }
			    else if(inBox(mx,my,5.5,5.5 + BUTTON_WIDTH,2,2 + BUTTON_HEIGHT)){   //help��ť 
					  if(Start){
                     	break;
                      }
					  if(isLogin){
					  	break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  fillR(5.45,1.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(5.5,2,"Help");
					  Help();
				  }
				else if(inBox(mx,my,3.5,3.5 + BUTTON_WIDTH,1,1 + BUTTON_HEIGHT)){   //rank��ť 
					  if(Start){
                     	break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(isRank){
                      	  break;
                      } 
					  isRank = 1;
					  fillR(3.45,0.9,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(3.5,0.9,"Rank");
					  fillR(0,0,winwidth,winheight,"white");
					  DrawPicture("rankback1.bmp");
				      DrawButton(5,0.8,"Return");
					  OutputInfo();
				}
				else if(inBox(mx,my,5,5 + BUTTON_WIDTH,0.8,0.8 + BUTTON_HEIGHT)){   //return��ť 
				      if(Start){
                     	  break;
                      }
					  if(isLogin){
					  	  break;
					  }
					  if(!isRank){
                      	  break;
                      } 
					  isRank = 0;
					  fillR(4.95,0.7,2.2,0.65,"white");
					  SetPenColor(PenColor[_color]);
				      DrawButton(5,0.8,"Return");
					  fillR(0,0,winwidth,winheight,"white");
					  DrawPicture("background1.bmp");
					  DrawMenu();	
				}
				else break;
			}
			else if (button == RIGHT_BUTTON) {} 
              break;
        case MOUSEMOVE:
            break;
    }	

}

//�ַ���Ϣ�ص����� 
void CharEventProcess(char c)
{
	int len;

	if (!inText) return;
    switch (c) {
    	case 27:   //ESC
    	case '\r':  //enter�� 
			inText = FALSE; //�˳���ǰ�ı����� ����ֱ�ӽ�����Ϸ 
			if(isLogin){
		      Start = 1; 
			  isLogin = 0;
			  isRank = 0;
			  fillR(3.45,2.4,2.2,0.65,"white");
			  SetPenColor(PenColor[_color]);
		      DrawButton(3.5,2.5,"Ready");
		  	  isCursorBlink = FALSE; 
		  	  inText = FALSE;
		  	  cancelTimer(2);
			  SetPenColor("white");
		  	  fillRectangle(0, 0, winwidth, winheight);
			  strcpy(newplayer.name , textbuf);
			  strcpy(nameID, newplayer.name);
			  SetPenColor("white");
		  	  fillRectangle(0, 0, winwidth, winheight); 
			  DrawPicture("background2.bmp");
			  SetPenColor("white");
	          fillRectangle(0, 0, GAME_WIDTH, GAME_HEIGHT);
			  DrawArea();
	          InitSnake();
	          CreatFood();
	          DrawSnake();
	          ShowCurrentSpeed();  
	          ShowCurrentColor(); 
	          scoretip(); 
	          DrawButton(7.5,2.4,"ReStart |F3");
	          DrawButton(7.5,1.7,"Color |F2");
	          DrawButton(7.5,1.0,"Play |SPACE"); 
	          DrawButton(7.5,0.3,"Exit |ESC"); 
	          char nametip[100];
	  	      MovePen(7.6,6.5);
	  	      SetPenColor("blue"); 
		      sprintf(nametip," Welcome !!  Dr. %s", textbuf);
		  	  DrawTextString(nametip);
	      	}
			if(!Start){
				break;
			}
			if(!isRank){
				break;
			}
			break;
 	    case '\b':  //�ո�� 
 	        if(!inText) break;
 	    	if ((len = strlen(textbuf)) == 0) break;
			SetEraseMode(TRUE);
			MovePen(tptr->x, tptr->y);
			DrawTextString(textbuf);
			DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);/*������ǰ���*/
			DeleteCharFromString(textbuf, tptr->curPos-1);
	 	   	SetEraseMode(FALSE);
	 	   	MovePen(tptr->x, tptr->y);
	 	   	DrawTextString(textbuf);
	 	   	if (tptr->curPos > 0) tptr->curPos--;
	 	   	DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);/*��ʾ��ǰ���*/
 	    	break;
    	default:
    		if(!inText) break;
    		if ((len = strlen(textbuf)) >= TEXTLEN) break; 
			SetEraseMode(TRUE);
			MovePen(tptr->x, tptr->y);
			DrawTextString(textbuf);
			DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);/*������ǰ���*/
			InsertCharToString(textbuf, tptr->curPos, c);/*����ǰ�ַ����뵽���λ��*/
	 	   	SetEraseMode(FALSE);
	 	   	MovePen(tptr->x, tptr->y);
	 	   	DrawTextString(textbuf);
	 	   	tptr->curPos++; 
	 	   	DrawCursor(textbuf, tptr->curPos, tptr->x, tptr->y);/*��ʾ��ǰ���*/
			break;
    }
}

