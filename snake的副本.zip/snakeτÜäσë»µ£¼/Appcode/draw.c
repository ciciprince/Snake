
#include "graphics.h"
#include "extgraph.h"
#include "windows.h"
#include "conio.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>

#include "basicgame.h"
#include "menu.h"
#include "hardware.h"
#include "rank.h"
#include "draw.h"

#define  INIT_X                0      
#define  INIT_Y                0      
#define  GAME_WIDTH            7      
#define  GAME_HEIGHT           7      
#define  BUTTON_WIDTH          2    
#define  BUTTON_HEIGHT         0.5    
#define  BOX_WIDTH             0.292 
#define  BODY_WIDTH            0.146  

#define CURSOR "_"             
#define CURSOR_BLINK  1        
#define TEXTLEN  100

extern char* PenColor[6];
extern char* Speed[4];
extern int show_more_buttons;
extern int _color;
extern double winwidth, winheight;
extern int isAccelerate;
extern int CurrentDirection;
extern int LastDirection;
extern int TempDirection; 
extern int speed;
extern bool isStart;
extern int domain[24][24];
extern isLogin;
extern StartButton;
extern isRank;
extern int score, add;
extern int GameLevel;
extern bool isEnd;
extern bool isClear;


void DrawApple(double x, double y){
	SetPenColor("red");
	MovePen(x + 0.292 / 2,y);
	StartFilledRegion(1);
	DrawArc(BOX_WIDTH/2.5,-90,360);
	EndFilledRegion();
	SetPenColor("black");
	MovePen(x + 0.292 / 2, y + 0.15);
	DrawLine(0,0.142);
	MovePen(x + 0.292 / 2, y + 0.15);
	DrawArc(BOX_WIDTH/3,-90,40);
	MovePen(x + 0.292 / 2, y + 0.15);
	DrawArc(BOX_WIDTH/3.2,-90,-40);
	
} 

void DrawButton(double dx, double dy, const string str){//����ť������Ϊ���½ǵ������Լ���ť���� 
	SetPenSize(2);
	SetPenColor("orange");
	MovePen(dx, dy);
    DrawLine(BUTTON_WIDTH, 0);
    DrawLine(0, BUTTON_HEIGHT);
    DrawLine(-BUTTON_WIDTH,0);
    DrawLine(0, -BUTTON_HEIGHT);
    SetPenSize(1);
    MovePen(dx+0.05, dy+0.05);
    DrawLine(1.9, 0);
    DrawLine(0, 0.4);
    DrawLine(-1.9,0);
    DrawLine(0, -0.4);
    SetPenColor("red");
    MovePen(dx + BUTTON_WIDTH / 2 - 0.3 , dy + 0.2);
	DrawTextString(str);
}

void EraseButton(double dx, double dy, const string str){
	SetPenSize(2);
	SetEraseMode(TRUE);
	MovePen(dx, dy);
    DrawLine(BUTTON_WIDTH, 0);
    DrawLine(0, BUTTON_HEIGHT);
    DrawLine(-BUTTON_WIDTH,0);
    DrawLine(0, -BUTTON_HEIGHT);
    SetPenSize(1);
    MovePen(dx+0.05, dy+0.05);
    DrawLine(1.9, 0);
    DrawLine(0, 0.4);
    DrawLine(-1.9,0);
    DrawLine(0, -0.4);
    MovePen(dx + BUTTON_WIDTH / 2 - 0.3 , dy + 0.2);
	DrawTextString(str);
	SetEraseMode(FALSE);
}


void DrawWall(double x, double y){
	fillR(x,y,BOX_WIDTH,BOX_WIDTH,"orange");
	
	fillR(x+0.1,y+0.1,BOX_WIDTH-0.14,BOX_WIDTH-0.14,"white");
}

void DrawArea(){
	int i = 0;
	switch(GameLevel){
		case 0:
			for(i = 0;i < 24; i++){
				if(i<3||i>=8){
					DrawWall(i*BOX_WIDTH,0);
				    DrawWall(i*BOX_WIDTH,23*BOX_WIDTH);
				}
			DrawWall(0,i*BOX_WIDTH);
			DrawWall(23*BOX_WIDTH,i*BOX_WIDTH);
		    }	
		    break;
	    case 1:
	    	for(i = 0;i < 24; i++){
				
				DrawWall(i*BOX_WIDTH,0);
				DrawWall(i*BOX_WIDTH,23*BOX_WIDTH);
			    DrawWall(0,i*BOX_WIDTH);
			    DrawWall(23*BOX_WIDTH,i*BOX_WIDTH);
		    }
			for(i = 9;i < 15;i++){
				DrawWall(i*BOX_WIDTH,9*BOX_WIDTH);
				DrawWall(i*BOX_WIDTH,14*BOX_WIDTH);
			    DrawWall(9*BOX_WIDTH,i*BOX_WIDTH);
			    DrawWall(14*BOX_WIDTH,i*BOX_WIDTH);
			}
			break;
		case 2:
		    for(i = 0; i < 9; i++){
		    	DrawWall(i*BOX_WIDTH,0);
		    	DrawWall((23 - i)*BOX_WIDTH,0);
		    	DrawWall(0,i*BOX_WIDTH);
		    	DrawWall(0,(23 - i)*BOX_WIDTH);
		    	DrawWall(i*BOX_WIDTH,23*BOX_WIDTH);
		    	DrawWall((23 - i)*BOX_WIDTH,23*BOX_WIDTH);
		    	DrawWall(23*BOX_WIDTH,i*BOX_WIDTH);
		    	DrawWall(23*BOX_WIDTH,(23 - i)*BOX_WIDTH);
		    }
			for(i = 6;i < 10;i++){
				//���½������ο� 
				DrawWall(i*BOX_WIDTH,6*BOX_WIDTH);
				DrawWall(i*BOX_WIDTH,9*BOX_WIDTH);
			    DrawWall(6*BOX_WIDTH,i*BOX_WIDTH);
			    DrawWall(9*BOX_WIDTH,i*BOX_WIDTH);
			    //���Ͻ������ο� 
			    DrawWall(i*BOX_WIDTH,17*BOX_WIDTH);
				DrawWall(i*BOX_WIDTH,14*BOX_WIDTH);
			    DrawWall(6*BOX_WIDTH,(23 - i)*BOX_WIDTH);
			    DrawWall(9*BOX_WIDTH,(23 - i)*BOX_WIDTH);
			    //���½������ο� 
			    DrawWall((23 - i)*BOX_WIDTH,6*BOX_WIDTH);
				DrawWall((23 - i)*BOX_WIDTH,9*BOX_WIDTH);
			    DrawWall(17*BOX_WIDTH,i*BOX_WIDTH);
			    DrawWall(14*BOX_WIDTH,i*BOX_WIDTH);
			    //���Ͻ������ο� 
			    DrawWall((23 - i)*BOX_WIDTH,17*BOX_WIDTH);
				DrawWall((23 - i)*BOX_WIDTH,14*BOX_WIDTH);
			    DrawWall(17*BOX_WIDTH,(23 - i)*BOX_WIDTH);
			    DrawWall(14*BOX_WIDTH,(23 - i)*BOX_WIDTH);
			}	
	}
} 

void DrawBody(double x, double y){  
	SetPenSize(1);
    MovePen(x+2*BODY_WIDTH, y+BODY_WIDTH);
    DrawArc(BODY_WIDTH,0,360);
}

void DrawBox(double x, double y){  
	SetPenSize(1);
    MovePen(x, y);
    DrawLine(BOX_WIDTH,0);
    DrawLine(0,BOX_WIDTH);
    DrawLine(-BOX_WIDTH,0);
    DrawLine(0,-BOX_WIDTH);
     
}

void fillRectangle(double x, double y, double w, double h)
{
    MovePen(x, y);
    StartFilledRegion(0.5);//��ʼ
        DrawLine(0, h);
        DrawLine(w, 0);
        DrawLine(0, -h);
        DrawLine(-w, 0);
    EndFilledRegion();//����
}

void fillR(double x, double y, double w, double h,string color){
	MovePen(x, y);
    SetPenColor(color);
    StartFilledRegion(0.5); // ��ʼ
	    DrawLine(0, h);
	    DrawLine(w, 0);
	    DrawLine(0, -h);
	    DrawLine(-w, 0);
    EndFilledRegion();   // ����
    SetEraseMode(TRUE);
    MovePen(x, y);
    DrawLine(0, h);
    DrawLine(w, 0);
    DrawLine(0, -h);
    DrawLine(-w, 0);
    SetEraseMode(FALSE);
    
}


void DrawSnake(){
	int i,j;
	SetPenColor(PenColor[_color]);           //�����趨Ϊ��ɫ 
	
	for(i=0;i<24;i++){                        //������ͼ���������� 
		for(j=0;j<24;j++){
			if(domain[i][j]==1||domain[i][j]==2||domain[i][j]==3||domain[i][j]==4){
				StartFilledRegion(1); 
				DrawBody(i*BOX_WIDTH,j*BOX_WIDTH);	
			    EndFilledRegion();
			}	
			else if(domain[i][j]==5)
			{
				SetPenColor(PenColor[_color]);                                 
			}
		}
	}
	if(isClear != 0){
		SetEraseMode(TRUE);
		if(isClear == 1){
			SnakeHead((23 - head.x)*BOX_WIDTH,head.y*BOX_WIDTH);
		}
		else if(isClear == 2){
			SnakeHead(head.x*BOX_WIDTH,(23 - head.y)*BOX_WIDTH);
		} 
		SetEraseMode(FALSE);
		isClear = 0;
	}
	DrawHead();
}
void SnakeHead(double x, double y){
	SetPenColor("orange");    
	StartFilledRegion(1);
	MovePen(x+2*BODY_WIDTH, y+BODY_WIDTH);
    DrawArc(BODY_WIDTH,0,360);
	EndFilledRegion();
	SetPenColor("white");
	switch(CurrentDirection){
		case 1:
			StartFilledRegion(1);  
			MovePen(x+1.866*BODY_WIDTH, y+1.5*BODY_WIDTH);    //���� 
		    DrawArc(BODY_WIDTH,30,-60);
		    EndFilledRegion();
		    StartFilledRegion(1); 
			MovePen(x+BODY_WIDTH, y+BODY_WIDTH);                 //������ 
			DrawLine(BODY_WIDTH*0.866,BODY_WIDTH*0.5);
			DrawLine(0,-BODY_WIDTH);
			DrawLine(-BODY_WIDTH*0.866,BODY_WIDTH*0.5);
			EndFilledRegion();
			SetPenColor("black");
			MovePen(x+0.8*BODY_WIDTH,y+1.2*BODY_WIDTH);    //�۾� 
			StartFilledRegion(1);
			DrawArc(0.02,0,360);
			EndFilledRegion();
			break;
		case 2:
			StartFilledRegion(1);  
			MovePen(x+1.5*BODY_WIDTH, y+1.866*BODY_WIDTH);
		    DrawArc(BODY_WIDTH,60,60);
		    EndFilledRegion();
		    StartFilledRegion(1); 
			MovePen(x+BODY_WIDTH, y+BODY_WIDTH);
			DrawLine(BODY_WIDTH*0.5,BODY_WIDTH*0.866);
			DrawLine(-BODY_WIDTH,0);
			DrawLine(BODY_WIDTH*0.5,-BODY_WIDTH*0.866);
			EndFilledRegion();
			SetPenColor("black");
			MovePen(x+0.8*BODY_WIDTH,y+0.8*BODY_WIDTH);    //�۾� 
			StartFilledRegion(1);
			DrawArc(0.02,0,360);
			EndFilledRegion();
			break;
		case 3:
			StartFilledRegion(1);  
			MovePen(x+0.134*BODY_WIDTH, y+1.5*BODY_WIDTH);
		    DrawArc(BODY_WIDTH,150,60);
		    EndFilledRegion();
		    StartFilledRegion(1); 
			MovePen(x+BODY_WIDTH, y+BODY_WIDTH);
			DrawLine(-BODY_WIDTH*0.866,BODY_WIDTH*0.5);
			DrawLine(0,-BODY_WIDTH);
			DrawLine(BODY_WIDTH*0.866,BODY_WIDTH*0.5);
			EndFilledRegion();
			SetPenColor("black");
			MovePen(x+1.2*BODY_WIDTH,y+1.2*BODY_WIDTH);    //�۾� 
			StartFilledRegion(1);
			DrawArc(0.02,0,360);
			EndFilledRegion();
			break;
		case 4:
			StartFilledRegion(1);  
			MovePen(x+01.5*BODY_WIDTH, y+0.134*BODY_WIDTH);
		    DrawArc(BODY_WIDTH,-60,-60);
		    EndFilledRegion();
		    StartFilledRegion(1); 
			MovePen(x+BODY_WIDTH, y+BODY_WIDTH);
			DrawLine(BODY_WIDTH*0.5,-BODY_WIDTH*0.866);
			DrawLine(-BODY_WIDTH,0);
			DrawLine(BODY_WIDTH*0.5,BODY_WIDTH*0.866);
			EndFilledRegion();
			SetPenColor("black");
			MovePen(x+0.8*BODY_WIDTH,y+1.2*BODY_WIDTH);    //�۾� 
			StartFilledRegion(1);
			DrawArc(0.02,0,360);
			EndFilledRegion();
			break;
	} 
	
	SetPenColor(PenColor[_color]);
}
void DrawHead(){
	
	SetEraseMode(TRUE);
	switch(CurrentDirection){
		case 1:
			SnakeHead((head.x-1)*BOX_WIDTH,head.y*BOX_WIDTH);
			break;
		case 2:
			SnakeHead(head.x*BOX_WIDTH,(head.y-1)*BOX_WIDTH);
			break;
		case 3:
			if(head.x != 23){
				SnakeHead((head.x+1)*BOX_WIDTH,head.y*BOX_WIDTH);
			}
			
			break;
		case 4:
			SnakeHead(head.x*BOX_WIDTH,(head.y+1)*BOX_WIDTH);
			break;
	}
	DrawBody(head.x*BOX_WIDTH,head.y*BOX_WIDTH);
	SetEraseMode(FALSE);
	LastDirection = TempDirection;
	StartFilledRegion(1);
	switch(LastDirection){
		case 1:
			DrawBody((head.x-1)*BOX_WIDTH,head.y*BOX_WIDTH);
			break;
		case 2:
			DrawBody(head.x*BOX_WIDTH,(head.y-1)*BOX_WIDTH);
			break;
		case 3:
			if(head.x != 23){
				DrawBody((head.x+1)*BOX_WIDTH,head.y*BOX_WIDTH);
			}
			    
			break;
		case 4:
			DrawBody(head.x*BOX_WIDTH,(head.y+1)*BOX_WIDTH);
			break;
	}
	EndFilledRegion();
	TempDirection = CurrentDirection;
	SnakeHead(head.x*BOX_WIDTH,head.y*BOX_WIDTH);
	if((head.x == 0 && CurrentDirection == 3)|| (head.x == 23 &&CurrentDirection == 1)){
		isClear = 1;
	}
	else if((head.y == 0 && CurrentDirection == 4)||(head.y == 23 && CurrentDirection == 2)){
		isClear = 2; 
	}
}


void LevelTravel(int level){
	switch(level){
		case(1):
			cancelTimer(1);
			MessageBox(NULL,TEXT("\n\n\n\tN O W   L E V E L  T W O            \n\n\n\n \tE N J O Y  Y O U R S E L F !\n\n\n\t"),TEXT("                C O N G R A T U L A T I O N S "),MB_OK);
		    break;
		case(2):
			cancelTimer(1);
			MessageBox(NULL,TEXT("\n\n\n\tN O W   L E V E L  T H R E E            \n\n\n\n \tE N J O Y  Y O U R S E L F !\n\n\n\t"),TEXT("                C O N G R A T U L A T I O N S !"),MB_OK);
		    break;
		default:
	     	break;	
	}
}





