
#include "graphics.h"
#include "extgraph.h"
#include "strlib.h"
#include <math.h>
#include "conio.h"
#include <windows.h>

#include "menu.h"
#include "hardware.h"
#include "basicgame.h"
#include "rank.h"
#include "draw.h"

#define  INIT_X                0      
#define  INIT_Y                0      
#define  GAME_WIDTH            7      
#define  GAME_HEIGHT           7      
#define  BUTTON_WIDTH          2    
#define  BUTTON_HEIGHT         0.5    
#define  BOX_WIDTH             0.292  

#define CURSOR "_"             
#define CURSOR_BLINK  1        
#define TEXTLEN  100

extern TextT curText;          
extern int timerseconds;       
extern bool isCursorBlink;     
extern TextT tptr;             
extern bool inText;            
extern char textbuf[TEXTLEN+1];
extern char* PenColor[6];       
extern char* Speed[4];         
extern int show_more_buttons;
extern int _color;              
extern double winwidth, winheight;
extern int isAccelerate;       
extern int CurrentDirection;    
extern int d;                   
extern int speed;               
extern bool isStart;            
extern int domain[24][24];        
extern isLogin;                
extern Start;             
extern int isRank;
extern int high, low;
extern int score, add;
extern char nameID[20];
extern bool isEnd;
extern int GameLevel;

void DrawMenu()	//����ʼҳ�� 
{	
    DrawButton(1.5, 3,"Register"); 
	DrawButton(5.5, 3,"Start"); 
	DrawButton(1.5, 2,"About");
	DrawButton(5.5, 2,"Help");
	DrawButton(3.5, 1,"Rank");
}


void Register()
{
	SetPenColor("white");
	fillRectangle(0, 0, winwidth, winheight);
	DrawPicture("background3.bmp");
	SetPenColor("brown");
	MovePen(2.8, 3.5);
	DrawTextString("Please enter your ID :");
	scanf("%s",newplayer.name);
	DrawButton(3.5,2.5,"Ready");
}


void About()
{
	MessageBox(NULL,TEXT("Dear friends ��\t\t\n\n\t��֪��̰��������С���Ա\t\t\n\n\tף��\t\n\n\t��Ϸ��죡\t"),TEXT("����"),MB_OK);
}

void Help()
{
	MessageBox(NULL,TEXT("Dear friends ��\t\t\n\n\t1)�ɼ��̵ġ� �� �� �� �����ߵ��ƶ�\t\t\n\n\t2)����ײǽ������ҧ���Լ�\t\n\n\t3)�� F3 ����\t\n\n\t4)�� F1 ���٣�F2 ��ɫ, SPACE ��ʼ/��ͣ\n\n\t5)����״̬�£�����������~"),TEXT("����"),MB_OK);
}


void PrintRank(void){
	
}

 void DrawTextT(void *text)
{
	TextT tptr = (TextT)text;
	string color = GetPenColor();
	int pointsize = GetPointSize();
	MovePen(tptr->x, tptr->y);
	SetPenColor(tptr->color);
	SetPointSize(tptr->PointSize);
    DrawTextString(tptr->text);
    SetPenColor(color);
    SetPointSize(pointsize);
}


void DrawCursor(string str, int curPos, double startx, double starty)//�����
{
	if (curPos < 0 || curPos > strlen(str)) return;
	MovePen(startx+TextStringWidth(SubString(str, 0, curPos-1)), starty);
	DrawTextString(CURSOR);
	return;
}
 
bool TextEqual(void *text1, void *text2)
{
	TextT tptr1 = (TextT)text1, tptr2 = (TextT)text2;

	return StringEqual(tptr1->text, tptr2->text) &&
           tptr1->x == tptr2->x && tptr1->y == tptr2->y;
}

double distText(double x, double y, TextT text)
{
	return fabs(x - text->x) + fabs(y - text->y);
}

/*Insert char c to the string str at the position pos*/
void InsertCharToString(string str, int pos, char c)
{
	int len;
	
	if (pos < 0 || pos >= TEXTLEN) return;
	len = strlen(str);
	*(str+len+1) = '\0'; //������γ��ַ���
	while (len > pos) {
		*(str+len) = *(str+len-1);
		len--;
	}	
	*(str+len) = c;
	return;
}


void DeleteCharFromString(string str, int pos)//Delete the character at the pos position of string str
{
	int len;
	
	len = strlen(str);
	if (pos < 0 || pos >= len) return;
	
	while (*(str+pos) != '\0') {
		*(str+pos) = *(str+pos+1);
		pos++; 
	}
	return;
}
